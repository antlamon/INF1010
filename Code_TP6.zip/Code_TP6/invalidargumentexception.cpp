
InvalidArgumentException::InvalidArgumentException(string what) : logic_error(what)
{}
